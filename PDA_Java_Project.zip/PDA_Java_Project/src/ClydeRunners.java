// Glasgow Clyde Runners App

// importing java libraries
import java.util.InputMismatchException;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.File;
import java.io.PrintWriter;


public class ClydeRunners  {

    // declaration of global variables which can be accessed by all methods
    public static File filename;
    public static Scanner input; // declaration of global scanner used to read file.
    public static Scanner user_input = new Scanner(System.in); // declaration of global scanner for user input
    public static String [][] raceResults = new String [16][3]; //declaration of 2D array which is used to store race results file data
    //1D arrays declaration to store individual data from 2D array
    public static String [] firstName = new String [16];
    public static String [] lastName = new String[16];
    public static int [] speed = new int[16];


// main method to accept user password and validate it against system password

    public static void main(String[] args) throws FileNotFoundException {

        String password = "clyderunners"; // set password to access the app
        int fail =3;    // set value to count number of failed attempts

        do{

            System.out.println("\n------------------Glasgow Clyde Runners Club---------------------");
            System.out.println("Welcome to Glasgow Clyde Runners Club.");
            System.out.print("Enter password: ");
            String login = user_input.nextLine();
            // validation of user entered password
            if(login.equals(password)){
                System.out.println("Password validated.");
                Menu();  // if password matches call method Menu
                System.exit(0);

            }
            else{
                fail--; // if password not matched, minus attempts by 1 and repeat loop
                System.out.println("You have entered incorrect password.");
                System.out.println("You have "+fail+" attempts left."); // show user the remaining attempts
            }

        }while(fail!=0); // set condition for loop

        //If user failed to enter correct password 3 times, show user locked out message and exit program.
        System.out.println("Number of attempts exceeded. You are locked out. ");
        System.exit(0);

    }
    // A method to show Menu to the user
    public static void Menu() throws FileNotFoundException {

        int option;
        // this loop allows user to access menu until they enter exit
        do {
            System.out.println("\n------------------Glasgow Clyde Runners Club---------------------");
            System.out.println("   Menu");
            System.out.println("  1. Read and Display records.");
            System.out.println("  2. Sort and print recorded times.");
            System.out.println("  3. Show fastest recorded time.");
            System.out.println("  4. Show slowest recorded time.");
            System.out.println("  5. Search for time in records.");
            System.out.println("  6. Number of Occurrences.");
            System.out.println("  7. Exit");
            System.out.print("\nPlease enter your option: ");
            option = user_input.nextInt();

                //if else conditions to choose given options and call correct methods.
                if (option == 1) {
                    showRecord();
                } else if (option == 2) {
                    showSortedList();
                } else if (option == 3) {
                    showFastest();
                } else if (option == 4) {
                    showSlowest();
                } else if (option == 5) {
                    System.out.print("Enter the time to be searched: ");
                    int ans = user_input.nextInt();
                    searchTime(ans);
                } else if (option == 6) {
                    System.out.print("Enter the time to be searched: ");
                    int ans = user_input.nextInt();
                    searchOccurrences(ans);
                } else if (option == 7) {
                    System.out.println("\nThank you for using Glasgow Clyde Runner app. Goodbye!!");
                    user_input.close(); // close scanner and exit program.
                    System.exit(0);
                } else {
                    System.out.println("\n" + "Please enter correct choice.");
                }


        }
        while (option != 7); // loop variable option until exit is pressed



        }




    // a method to access race results file and save data in 2D array and individual data in 1D arrays
    public static void setArray() throws FileNotFoundException{

        String nameOfFile = "src/race_results.txt"; // 400m race results input text file
        filename = new File(nameOfFile);
        input = new Scanner(filename); // new scanner to read file content

        while(input.hasNextLine()){
            //a loop to add data to 2D array until end of file reached
            for (String[] raceResult : raceResults) {
                String[] line = input.nextLine().split(" ");
                System.arraycopy(line, 0, raceResult, 0, line.length); // copy content in 2D array

            }
        }
        // for loop to iterate 2D array and save individual data to 1D arrays
        for(int i=0; i< raceResults.length;i++){

            firstName[i] = raceResults[i][0];
            lastName[i] = raceResults[i][1];
            speed[i] = Integer.parseInt(raceResults[i][2]);

        }

        input.close(); //close scanner user for file operations

    }
    // a method to display 400m race runner's first name, last name and respective running speed in seconds
    public static void showRecord()throws FileNotFoundException{
        setArray();
        System.out.println("First Name   Last Name   Running time(seconds)");

        for(int i=0; i< raceResults.length;i++){ // for loop to iterate individual 1D array and show results

            firstName[i] = raceResults[i][0];
            lastName[i] = raceResults[i][1];
            speed[i] = Integer.parseInt(raceResults[i][2]);
            System.out.printf("%-15s%-15s%-15s\n" ,firstName[i],lastName[i],speed[i]);
        }
    }
    // a method to find the slowest runner name and running time in 400m race
    public static void showSlowest() throws FileNotFoundException{

        String outputFile = "src/slowestOutput.txt";
        PrintWriter slowestOutputFile = new PrintWriter(outputFile); // new print writer to save output in a file
        int slowestRunner = speed[0];  //set first item to slowest
        String runnerName = "";  // save runners name
        setArray(); // invoke setArray method to save content from input file to 2D array and individual data in 1D arrays

        // for each item in speed array starting with second item
        for (int i =1; i< speed.length; i++){

            if( slowestRunner > speed[i]){  //if next item is slowest
                slowestRunner = speed[i];  //set current item to slowest and save runner name
                runnerName = firstName[i];
            }
        }
        slowestOutputFile.write("\n------------------Glasgow Clyde Runners Club---------------------");
        slowestOutputFile.write("\nThe slowest running time "+ slowestRunner + " achieved by "+runnerName);
        System.out.println("\n------------------Glasgow Clyde Runners Club---------------------");
        System.out.println("The slowest running time "+ slowestRunner + " achieved by "+runnerName);
        slowestOutputFile.close(); // close file writer

    }
    // a method to find the fastest runner name and running time in 400m race
    public static void showFastest() throws FileNotFoundException{

        String outputFile = "src/fastestOutput.txt";

        PrintWriter fastestOutputFile = new PrintWriter(outputFile); // new print writer to save output in a file
        int fastestRunner = speed[0]; //set first item to fastest
        String runnerName = ""; // save runners name
        setArray(); // invoke setArray method to save content from input file to 2D array and individual data in 1D arrays

        // for each item in speed array starting with second item
        for (int i =1; i< speed.length; i++){

            if( fastestRunner < speed[i]){ //if next item is fastest
                fastestRunner = speed[i];  //set current item to fastest and save runner name
                runnerName = firstName[i];

            }

        }
        fastestOutputFile.write("\n------------------Glasgow Clyde Runners Club---------------------");
        fastestOutputFile.write("\nThe fastest running time "+ fastestRunner + " achieved by "+runnerName);
        System.out.println("\n------------------Glasgow Clyde Runners Club---------------------");
        System.out.println("The fastest running time "+ fastestRunner + " achieved by "+runnerName);
        fastestOutputFile.close();// close file writer
    }

    // a method sort the speed from slowest to fastest
    public static void showSortedList() throws FileNotFoundException{

        String outputFile = "src/sortedOutput.txt";
        PrintWriter sortedOutput = new PrintWriter(outputFile); //new print writer to write in file
        int [] sortedSpeed = new int[16]; // local arrays for saving sorted output
        String [] fName = new String[16];
        String [] lName = new String[16];

        int temp;       // temp variable used in exchanging values
        String temp1 = "";
        String temp2 = "";
        setArray(); // invoke setArray method to save content from input file to 2D array and individual data in 1D arrays

        // make copies in local arrays to sort speed
        System.arraycopy(speed, 0, sortedSpeed, 0, speed.length);
        System.arraycopy(firstName,0,fName,0,firstName.length);
        System.arraycopy(lastName,0,lName,0,lastName.length);

        //One by one move boundary of unsorted sub array
        //first iteration will check index 0 to last element in array
        //second iteration will check index 1 to last element in array
        //this will continue until all elements of unsorted array have been sorted
        for (int i =0;i<sortedSpeed.length ; i++){
            // Find the minimum element in unsorted sub array
            for (int j =i+1; j< sortedSpeed.length; j++){
                //start comparisons for each iteration boundary is moved forward by 1 each time
                if(sortedSpeed[i] > sortedSpeed[j]){
                    //check first element of array i against next element j and start comparing values until lowest value has been found in j

                    temp = sortedSpeed[i];      // exchange the values in elements using temp variable
                    sortedSpeed[i] = sortedSpeed[j];
                    sortedSpeed[j] = temp;

                    temp1 = fName[i];
                    fName[i] = fName[j];
                    fName[j] = temp1;

                    temp2 = lName[i];
                    lName[i] = lName[j];
                    lName[j] = temp2;
                }
            }
        }
        System.out.println("\n------------------Glasgow Clyde Runners Club---------------------");
        sortedOutput.write("\n------------------Glasgow Clyde Runners Club---------------------");
        System.out.println("Sorted Speed slowest to fastest :");
        sortedOutput.write("\nSorted Speed slowest to fastest :");
        for (int i=0;i<speed.length;i++) {

            System.out.printf("%-15s%-15s%-15s\n" ,fName[i],lName[i],sortedSpeed[i]);
            sortedOutput.write("\n"+fName[i]+"  "+lName[i]+"  "+sortedSpeed[i]);
        }

       sortedOutput.close(); // close file writer
    }

    // a method to search for given time by user
    public static void searchTime(int choice) throws FileNotFoundException {

        String outputFile = "src/recordFoundOutput.txt";
        PrintWriter recordOutput = new PrintWriter(outputFile); //new file writer to save result in file
        setArray();// invoke setArray method to save content from input file to 2D array and individual data in 1D arrays
        System.out.println("\n------------------Glasgow Clyde Runners Club---------------------");
        recordOutput.printf("\n------------------Glasgow Clyde Runners Club---------------------");

        for (int j : speed) {//for loop to iterate speed array
            if (choice == j) { // if searched time found in speed array save result
                recordOutput.printf("\n" + choice + " found in the record.");
                System.out.println(choice + " found in the record.");
                break;
            }
        }
        recordOutput.close();// close file writer

    }
    // a method to count number of occurrences in speed array
    public static void searchOccurrences(int choice) throws FileNotFoundException {
        int count = 0; // set counter to 0
        String outputFile = "src/searchOccurrencesOutput.txt";
        PrintWriter occurrencesOutput = new PrintWriter(outputFile); //new file writer to save result in file
        setArray();// invoke setArray method to save content from input file to 2D array and individual data in 1D arrays
        //for loop to iterate speed array
        for (int j : speed) {
            if (choice == j) {
                count++; //add one to count for each searched input found in speed array
            }
        }
        occurrencesOutput.write("\n------------------Glasgow Clyde Runners Club---------------------");
        occurrencesOutput.write("\n"+choice + " achieved "+ count + " times.");
        System.out.println("\n------------------Glasgow Clyde Runners Club---------------------");
        System.out.println("\n"+choice + " achieved "+ count + " times.");
        occurrencesOutput.close();// close file writer

    }
}
